#include "GeoGeometry.h"

GeoGeometry::GeoGeometry()
{
}

GeoGeometry::~GeoGeometry()
{
	
}

void GeoGeometry::setType(int t)
{
	type = t;
}

int GeoGeometry::getType()
{
	return type;
}
