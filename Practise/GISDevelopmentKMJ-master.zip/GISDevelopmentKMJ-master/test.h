#pragma once
class test
{
public:
	test(void);
	~test(void);
};

