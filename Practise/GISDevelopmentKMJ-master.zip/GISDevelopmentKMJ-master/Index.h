#pragma once
class Index
{
public:
	Index();
	~Index();
	void setType(int t);
	int getType();

protected:
	int type;

private:


};

