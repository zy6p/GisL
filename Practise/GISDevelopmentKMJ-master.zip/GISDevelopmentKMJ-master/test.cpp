#include "test.h"


test::test(void)
{
}


test::~test(void)
{
}
