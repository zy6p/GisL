#include "COption.h"
#include "EnumType.h"

COption::COption()
{
	type = EnumType::KERNEL_DENSITY_ANALYSIS;
}

COption::~COption()
{
}
