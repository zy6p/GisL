#include "Index.h"

Index::Index()
{
}

Index::~Index()
{
}

void Index::setType(int t)
{
	this->type = t;
}

int Index::getType()
{
	return type;
}
