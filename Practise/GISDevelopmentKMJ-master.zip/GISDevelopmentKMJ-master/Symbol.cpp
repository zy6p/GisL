#include "Symbol.h"



Symbol::Symbol()
{
}


Symbol::~Symbol()
{
}

int Symbol::getType()
{
	return type;
}
