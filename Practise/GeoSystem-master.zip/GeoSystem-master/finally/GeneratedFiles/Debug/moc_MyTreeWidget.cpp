/****************************************************************************
** Meta object code from reading C++ file 'MyTreeWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../MyTreeWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MyTreeWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MyTreeWidget_t {
    QByteArrayData data[43];
    char stringdata0[458];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MyTreeWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MyTreeWidget_t qt_meta_stringdata_MyTreeWidget = {
    {
QT_MOC_LITERAL(0, 0, 12), // "MyTreeWidget"
QT_MOC_LITERAL(1, 13, 18), // "updateTreeGLSignal"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 4), // "mode"
QT_MOC_LITERAL(4, 38, 8), // "CGeoMap*"
QT_MOC_LITERAL(5, 47, 3), // "map"
QT_MOC_LITERAL(6, 51, 7), // "layerID"
QT_MOC_LITERAL(7, 59, 4), // "size"
QT_MOC_LITERAL(8, 64, 19), // "updateLayerIDSignal"
QT_MOC_LITERAL(9, 84, 19), // "updateColorAndWidth"
QT_MOC_LITERAL(10, 104, 1), // "r"
QT_MOC_LITERAL(11, 106, 1), // "g"
QT_MOC_LITERAL(12, 108, 1), // "b"
QT_MOC_LITERAL(13, 110, 5), // "width"
QT_MOC_LITERAL(14, 116, 21), // "sendColorAndWidthData"
QT_MOC_LITERAL(15, 138, 5), // "index"
QT_MOC_LITERAL(16, 144, 9), // "fillColor"
QT_MOC_LITERAL(17, 154, 11), // "strokeColor"
QT_MOC_LITERAL(18, 166, 9), // "showAttri"
QT_MOC_LITERAL(19, 176, 10), // "CGeoLayer*"
QT_MOC_LITERAL(20, 187, 5), // "layer"
QT_MOC_LITERAL(21, 193, 10), // "IndexGrids"
QT_MOC_LITERAL(22, 204, 10), // "KDEAnalyze"
QT_MOC_LITERAL(23, 215, 14), // "setLayerClours"
QT_MOC_LITERAL(24, 230, 9), // "layerNAME"
QT_MOC_LITERAL(25, 240, 14), // "QList<QString>"
QT_MOC_LITERAL(26, 255, 8), // "propsKey"
QT_MOC_LITERAL(27, 264, 11), // "setLayerCol"
QT_MOC_LITERAL(28, 276, 5), // "attri"
QT_MOC_LITERAL(29, 282, 22), // "updateMyTreeWidgetSlot"
QT_MOC_LITERAL(30, 305, 9), // "itemClick"
QT_MOC_LITERAL(31, 315, 6), // "viewIt"
QT_MOC_LITERAL(32, 322, 8), // "deleteIt"
QT_MOC_LITERAL(33, 331, 14), // "sltShowPopMenu"
QT_MOC_LITERAL(34, 346, 7), // "serProp"
QT_MOC_LITERAL(35, 354, 9), // "openAttri"
QT_MOC_LITERAL(36, 364, 16), // "getColorAndWidth"
QT_MOC_LITERAL(37, 381, 14), // "showIndexGrids"
QT_MOC_LITERAL(38, 396, 14), // "hideIndexGrids"
QT_MOC_LITERAL(39, 411, 10), // "analyzeKDE"
QT_MOC_LITERAL(40, 422, 12), // "layerColours"
QT_MOC_LITERAL(41, 435, 12), // "getAttribute"
QT_MOC_LITERAL(42, 448, 9) // "attribute"

    },
    "MyTreeWidget\0updateTreeGLSignal\0\0mode\0"
    "CGeoMap*\0map\0layerID\0size\0updateLayerIDSignal\0"
    "updateColorAndWidth\0r\0g\0b\0width\0"
    "sendColorAndWidthData\0index\0fillColor\0"
    "strokeColor\0showAttri\0CGeoLayer*\0layer\0"
    "IndexGrids\0KDEAnalyze\0setLayerClours\0"
    "layerNAME\0QList<QString>\0propsKey\0"
    "setLayerCol\0attri\0updateMyTreeWidgetSlot\0"
    "itemClick\0viewIt\0deleteIt\0sltShowPopMenu\0"
    "serProp\0openAttri\0getColorAndWidth\0"
    "showIndexGrids\0hideIndexGrids\0analyzeKDE\0"
    "layerColours\0getAttribute\0attribute"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MyTreeWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    4,  124,    2, 0x06 /* Public */,
       8,    2,  133,    2, 0x06 /* Public */,
       9,    4,  138,    2, 0x06 /* Public */,
      14,    4,  147,    2, 0x06 /* Public */,
      18,    1,  156,    2, 0x06 /* Public */,
      21,    0,  159,    2, 0x06 /* Public */,
      22,    1,  160,    2, 0x06 /* Public */,
      23,    3,  163,    2, 0x06 /* Public */,
      27,    2,  170,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      29,    1,  175,    2, 0x08 /* Private */,
      30,    0,  178,    2, 0x08 /* Private */,
      31,    0,  179,    2, 0x08 /* Private */,
      32,    0,  180,    2, 0x08 /* Private */,
      33,    1,  181,    2, 0x08 /* Private */,
      34,    0,  184,    2, 0x08 /* Private */,
      35,    0,  185,    2, 0x08 /* Private */,
      36,    3,  186,    2, 0x08 /* Private */,
      37,    0,  193,    2, 0x08 /* Private */,
      38,    0,  194,    2, 0x08 /* Private */,
      39,    0,  195,    2, 0x08 /* Private */,
      40,    0,  196,    2, 0x08 /* Private */,
      41,    2,  197,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, 0x80000000 | 4, QMetaType::Int, QMetaType::Int,    3,    5,    6,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    6,
    QMetaType::Void, QMetaType::Float, QMetaType::Float, QMetaType::Float, QMetaType::Double,   10,   11,   12,   13,
    QMetaType::Void, QMetaType::Int, QMetaType::QColor, QMetaType::QColor, QMetaType::Float,   15,   16,   17,   13,
    QMetaType::Void, 0x80000000 | 19,   20,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, 0x80000000 | 25,    6,   24,   26,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    6,   28,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor, QMetaType::QColor, QMetaType::Float,   16,   17,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    6,   42,

       0        // eod
};

void MyTreeWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MyTreeWidget *_t = static_cast<MyTreeWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateTreeGLSignal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< CGeoMap*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 1: _t->updateLayerIDSignal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 2: _t->updateColorAndWidth((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 3: _t->sendColorAndWidthData((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2])),(*reinterpret_cast< QColor(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 4: _t->showAttri((*reinterpret_cast< CGeoLayer*(*)>(_a[1]))); break;
        case 5: _t->IndexGrids(); break;
        case 6: _t->KDEAnalyze((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->setLayerClours((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QList<QString>(*)>(_a[3]))); break;
        case 8: _t->setLayerCol((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: _t->updateMyTreeWidgetSlot((*reinterpret_cast< CGeoMap*(*)>(_a[1]))); break;
        case 10: _t->itemClick(); break;
        case 11: _t->viewIt(); break;
        case 12: _t->deleteIt(); break;
        case 13: _t->sltShowPopMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 14: _t->serProp(); break;
        case 15: _t->openAttri(); break;
        case 16: _t->getColorAndWidth((*reinterpret_cast< QColor(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        case 17: _t->showIndexGrids(); break;
        case 18: _t->hideIndexGrids(); break;
        case 19: _t->analyzeKDE(); break;
        case 20: _t->layerColours(); break;
        case 21: _t->getAttribute((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 2:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QString> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MyTreeWidget::*_t)(int , CGeoMap * , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::updateTreeGLSignal)) {
                *result = 0;
            }
        }
        {
            typedef void (MyTreeWidget::*_t)(int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::updateLayerIDSignal)) {
                *result = 1;
            }
        }
        {
            typedef void (MyTreeWidget::*_t)(float , float , float , double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::updateColorAndWidth)) {
                *result = 2;
            }
        }
        {
            typedef void (MyTreeWidget::*_t)(int , QColor , QColor , float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::sendColorAndWidthData)) {
                *result = 3;
            }
        }
        {
            typedef void (MyTreeWidget::*_t)(CGeoLayer * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::showAttri)) {
                *result = 4;
            }
        }
        {
            typedef void (MyTreeWidget::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::IndexGrids)) {
                *result = 5;
            }
        }
        {
            typedef void (MyTreeWidget::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::KDEAnalyze)) {
                *result = 6;
            }
        }
        {
            typedef void (MyTreeWidget::*_t)(int , QString , QList<QString> );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::setLayerClours)) {
                *result = 7;
            }
        }
        {
            typedef void (MyTreeWidget::*_t)(int , QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyTreeWidget::setLayerCol)) {
                *result = 8;
            }
        }
    }
}

const QMetaObject MyTreeWidget::staticMetaObject = {
    { &QTreeWidget::staticMetaObject, qt_meta_stringdata_MyTreeWidget.data,
      qt_meta_data_MyTreeWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MyTreeWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MyTreeWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MyTreeWidget.stringdata0))
        return static_cast<void*>(const_cast< MyTreeWidget*>(this));
    return QTreeWidget::qt_metacast(_clname);
}

int MyTreeWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTreeWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void MyTreeWidget::updateTreeGLSignal(int _t1, CGeoMap * _t2, int _t3, int _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MyTreeWidget::updateLayerIDSignal(int _t1, int _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MyTreeWidget::updateColorAndWidth(float _t1, float _t2, float _t3, double _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MyTreeWidget::sendColorAndWidthData(int _t1, QColor _t2, QColor _t3, float _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MyTreeWidget::showAttri(CGeoLayer * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MyTreeWidget::IndexGrids()
{
    QMetaObject::activate(this, &staticMetaObject, 5, Q_NULLPTR);
}

// SIGNAL 6
void MyTreeWidget::KDEAnalyze(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void MyTreeWidget::setLayerClours(int _t1, QString _t2, QList<QString> _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void MyTreeWidget::setLayerCol(int _t1, QString _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_END_MOC_NAMESPACE
