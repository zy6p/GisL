/****************************************************************************
** Meta object code from reading C++ file 'myclass.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../myclass.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'myclass.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MyClass_t {
    QByteArrayData data[46];
    char stringdata0[539];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MyClass_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MyClass_t qt_meta_stringdata_MyClass = {
    {
QT_MOC_LITERAL(0, 0, 7), // "MyClass"
QT_MOC_LITERAL(1, 8, 16), // "updateMyGLSignal"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 4), // "mode"
QT_MOC_LITERAL(4, 31, 11), // "const char*"
QT_MOC_LITERAL(5, 43, 8), // "filename"
QT_MOC_LITERAL(6, 52, 7), // "layerID"
QT_MOC_LITERAL(7, 60, 26), // "updateMyGLPostgresqlSignal"
QT_MOC_LITERAL(8, 87, 4), // "port"
QT_MOC_LITERAL(9, 92, 6), // "dbname"
QT_MOC_LITERAL(10, 99, 4), // "host"
QT_MOC_LITERAL(11, 104, 4), // "user"
QT_MOC_LITERAL(12, 109, 8), // "password"
QT_MOC_LITERAL(13, 118, 5), // "table"
QT_MOC_LITERAL(14, 124, 24), // "updateMyTreeWidgetSignal"
QT_MOC_LITERAL(15, 149, 8), // "CGeoMap*"
QT_MOC_LITERAL(16, 158, 3), // "map"
QT_MOC_LITERAL(17, 162, 10), // "updateData"
QT_MOC_LITERAL(18, 173, 4), // "size"
QT_MOC_LITERAL(19, 178, 19), // "updateLayerIDSignal"
QT_MOC_LITERAL(20, 198, 22), // "sendColorAndWidthData2"
QT_MOC_LITERAL(21, 221, 9), // "fillColor"
QT_MOC_LITERAL(22, 231, 11), // "strokeColor"
QT_MOC_LITERAL(23, 243, 5), // "width"
QT_MOC_LITERAL(24, 249, 21), // "sendColorAndWidthData"
QT_MOC_LITERAL(25, 271, 15), // "vector<QString>"
QT_MOC_LITERAL(26, 287, 5), // "names"
QT_MOC_LITERAL(27, 293, 8), // "KDEAnaly"
QT_MOC_LITERAL(28, 302, 15), // "sendLayerClours"
QT_MOC_LITERAL(29, 318, 5), // "attri"
QT_MOC_LITERAL(30, 324, 11), // "readGeoJson"
QT_MOC_LITERAL(31, 336, 9), // "readShape"
QT_MOC_LITERAL(32, 346, 13), // "saveShapefile"
QT_MOC_LITERAL(33, 360, 15), // "getDatabaseData"
QT_MOC_LITERAL(34, 376, 10), // "IndexGrids"
QT_MOC_LITERAL(35, 387, 12), // "clearContent"
QT_MOC_LITERAL(36, 400, 16), // "updateTreeGLSlot"
QT_MOC_LITERAL(37, 417, 17), // "updateLayerIDSlot"
QT_MOC_LITERAL(38, 435, 17), // "getPostgresqlSlot"
QT_MOC_LITERAL(39, 453, 20), // "getColorAndWidthData"
QT_MOC_LITERAL(40, 474, 6), // "search"
QT_MOC_LITERAL(41, 481, 10), // "finishHTTP"
QT_MOC_LITERAL(42, 492, 14), // "QNetworkReply*"
QT_MOC_LITERAL(43, 507, 5), // "reply"
QT_MOC_LITERAL(44, 513, 10), // "KDEAnalyze"
QT_MOC_LITERAL(45, 524, 14) // "getLayerClours"

    },
    "MyClass\0updateMyGLSignal\0\0mode\0"
    "const char*\0filename\0layerID\0"
    "updateMyGLPostgresqlSignal\0port\0dbname\0"
    "host\0user\0password\0table\0"
    "updateMyTreeWidgetSignal\0CGeoMap*\0map\0"
    "updateData\0size\0updateLayerIDSignal\0"
    "sendColorAndWidthData2\0fillColor\0"
    "strokeColor\0width\0sendColorAndWidthData\0"
    "vector<QString>\0names\0KDEAnaly\0"
    "sendLayerClours\0attri\0readGeoJson\0"
    "readShape\0saveShapefile\0getDatabaseData\0"
    "IndexGrids\0clearContent\0updateTreeGLSlot\0"
    "updateLayerIDSlot\0getPostgresqlSlot\0"
    "getColorAndWidthData\0search\0finishHTTP\0"
    "QNetworkReply*\0reply\0KDEAnalyze\0"
    "getLayerClours"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MyClass[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    3,  129,    2, 0x06 /* Public */,
       7,    8,  136,    2, 0x06 /* Public */,
      14,    1,  153,    2, 0x06 /* Public */,
      17,    4,  156,    2, 0x06 /* Public */,
      19,    2,  165,    2, 0x06 /* Public */,
      20,    4,  170,    2, 0x06 /* Public */,
      24,    4,  179,    2, 0x06 /* Public */,
      27,    1,  188,    2, 0x06 /* Public */,
      28,    2,  191,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      30,    0,  196,    2, 0x08 /* Private */,
      31,    0,  197,    2, 0x08 /* Private */,
      32,    0,  198,    2, 0x08 /* Private */,
      33,    0,  199,    2, 0x08 /* Private */,
      34,    0,  200,    2, 0x08 /* Private */,
      35,    0,  201,    2, 0x08 /* Private */,
      36,    4,  202,    2, 0x08 /* Private */,
      37,    2,  211,    2, 0x08 /* Private */,
      38,    6,  216,    2, 0x08 /* Private */,
      39,    4,  229,    2, 0x08 /* Private */,
      40,    0,  238,    2, 0x08 /* Private */,
      41,    1,  239,    2, 0x08 /* Private */,
      44,    1,  242,    2, 0x08 /* Private */,
      45,    2,  245,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, 0x80000000 | 4, QMetaType::Int,    3,    5,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    3,    6,    8,    9,   10,   11,   12,   13,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 15, QMetaType::Int, QMetaType::Int,    3,   16,    6,   18,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::QColor, QMetaType::QColor, QMetaType::Float,    6,   21,   22,   23,
    QMetaType::Void, 0x80000000 | 25, QMetaType::QColor, QMetaType::QColor, QMetaType::Float,   26,   21,   22,   23,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    6,   29,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 15, QMetaType::Int, QMetaType::Int,    3,   16,    6,   18,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    6,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    9,   10,   11,   12,   13,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::QColor, QMetaType::QColor, QMetaType::Float,    6,   21,   22,   23,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 42,   43,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    6,   29,

       0        // eod
};

void MyClass::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MyClass *_t = static_cast<MyClass *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateMyGLSignal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const char*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 1: _t->updateMyGLPostgresqlSignal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8]))); break;
        case 2: _t->updateMyTreeWidgetSignal((*reinterpret_cast< CGeoMap*(*)>(_a[1]))); break;
        case 3: _t->updateData((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< CGeoMap*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 4: _t->updateLayerIDSignal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: _t->sendColorAndWidthData2((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2])),(*reinterpret_cast< QColor(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 6: _t->sendColorAndWidthData((*reinterpret_cast< vector<QString>(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2])),(*reinterpret_cast< QColor(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 7: _t->KDEAnaly((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->sendLayerClours((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: _t->readGeoJson(); break;
        case 10: _t->readShape(); break;
        case 11: _t->saveShapefile(); break;
        case 12: _t->getDatabaseData(); break;
        case 13: _t->IndexGrids(); break;
        case 14: _t->clearContent(); break;
        case 15: _t->updateTreeGLSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< CGeoMap*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 16: _t->updateLayerIDSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 17: _t->getPostgresqlSlot((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6]))); break;
        case 18: _t->getColorAndWidthData((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2])),(*reinterpret_cast< QColor(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 19: _t->search(); break;
        case 20: _t->finishHTTP((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 21: _t->KDEAnalyze((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->getLayerClours((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 20:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MyClass::*_t)(int , const char * , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::updateMyGLSignal)) {
                *result = 0;
            }
        }
        {
            typedef void (MyClass::*_t)(int , int , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::updateMyGLPostgresqlSignal)) {
                *result = 1;
            }
        }
        {
            typedef void (MyClass::*_t)(CGeoMap * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::updateMyTreeWidgetSignal)) {
                *result = 2;
            }
        }
        {
            typedef void (MyClass::*_t)(int , CGeoMap * , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::updateData)) {
                *result = 3;
            }
        }
        {
            typedef void (MyClass::*_t)(int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::updateLayerIDSignal)) {
                *result = 4;
            }
        }
        {
            typedef void (MyClass::*_t)(int , QColor , QColor , float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::sendColorAndWidthData2)) {
                *result = 5;
            }
        }
        {
            typedef void (MyClass::*_t)(vector<QString> , QColor , QColor , float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::sendColorAndWidthData)) {
                *result = 6;
            }
        }
        {
            typedef void (MyClass::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::KDEAnaly)) {
                *result = 7;
            }
        }
        {
            typedef void (MyClass::*_t)(int , QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyClass::sendLayerClours)) {
                *result = 8;
            }
        }
    }
}

const QMetaObject MyClass::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MyClass.data,
      qt_meta_data_MyClass,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MyClass::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MyClass::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MyClass.stringdata0))
        return static_cast<void*>(const_cast< MyClass*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MyClass::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void MyClass::updateMyGLSignal(int _t1, const char * _t2, int _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MyClass::updateMyGLPostgresqlSignal(int _t1, int _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7, QString _t8)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)), const_cast<void*>(reinterpret_cast<const void*>(&_t6)), const_cast<void*>(reinterpret_cast<const void*>(&_t7)), const_cast<void*>(reinterpret_cast<const void*>(&_t8)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MyClass::updateMyTreeWidgetSignal(CGeoMap * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MyClass::updateData(int _t1, CGeoMap * _t2, int _t3, int _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MyClass::updateLayerIDSignal(int _t1, int _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MyClass::sendColorAndWidthData2(int _t1, QColor _t2, QColor _t3, float _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void MyClass::sendColorAndWidthData(vector<QString> _t1, QColor _t2, QColor _t3, float _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void MyClass::KDEAnaly(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void MyClass::sendLayerClours(int _t1, QString _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_END_MOC_NAMESPACE
