/****************************************************************************
** Meta object code from reading C++ file 'MyGLWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../MyGLWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MyGLWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MyGLWidget_t {
    QByteArrayData data[42];
    char stringdata0[419];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MyGLWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MyGLWidget_t qt_meta_stringdata_MyGLWidget = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MyGLWidget"
QT_MOC_LITERAL(1, 11, 14), // "showAttriTable"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 11), // "CGeoObject*"
QT_MOC_LITERAL(4, 39, 6), // "object"
QT_MOC_LITERAL(5, 46, 5), // "objID"
QT_MOC_LITERAL(6, 52, 10), // "KDEAnalyze"
QT_MOC_LITERAL(7, 63, 9), // "bandWidth"
QT_MOC_LITERAL(8, 73, 7), // "float**"
QT_MOC_LITERAL(9, 81, 3), // "loc"
QT_MOC_LITERAL(10, 85, 6), // "maxLoc"
QT_MOC_LITERAL(11, 92, 6), // "minLoc"
QT_MOC_LITERAL(12, 99, 14), // "updateMyGLSlot"
QT_MOC_LITERAL(13, 114, 4), // "mode"
QT_MOC_LITERAL(14, 119, 11), // "const char*"
QT_MOC_LITERAL(15, 131, 8), // "filename"
QT_MOC_LITERAL(16, 140, 7), // "layerID"
QT_MOC_LITERAL(17, 148, 24), // "updateMyGLPostgresqlSlot"
QT_MOC_LITERAL(18, 173, 4), // "port"
QT_MOC_LITERAL(19, 178, 6), // "dbname"
QT_MOC_LITERAL(20, 185, 4), // "host"
QT_MOC_LITERAL(21, 190, 4), // "user"
QT_MOC_LITERAL(22, 195, 8), // "password"
QT_MOC_LITERAL(23, 204, 5), // "table"
QT_MOC_LITERAL(24, 210, 10), // "updateData"
QT_MOC_LITERAL(25, 221, 8), // "CGeoMap*"
QT_MOC_LITERAL(26, 230, 3), // "map"
QT_MOC_LITERAL(27, 234, 4), // "size"
QT_MOC_LITERAL(28, 239, 13), // "updateLayerID"
QT_MOC_LITERAL(29, 253, 7), // "LayerID"
QT_MOC_LITERAL(30, 261, 21), // "getColorAndWidthData2"
QT_MOC_LITERAL(31, 283, 9), // "fillColor"
QT_MOC_LITERAL(32, 293, 11), // "strokeColor"
QT_MOC_LITERAL(33, 305, 5), // "width"
QT_MOC_LITERAL(34, 311, 22), // "getColorAndWidthOneObj"
QT_MOC_LITERAL(35, 334, 20), // "getColorAndWidthObjs"
QT_MOC_LITERAL(36, 355, 15), // "vector<QString>"
QT_MOC_LITERAL(37, 371, 5), // "names"
QT_MOC_LITERAL(38, 377, 7), // "restore"
QT_MOC_LITERAL(39, 385, 8), // "KDEAnaly"
QT_MOC_LITERAL(40, 394, 14), // "setLayerClours"
QT_MOC_LITERAL(41, 409, 9) // "attribute"

    },
    "MyGLWidget\0showAttriTable\0\0CGeoObject*\0"
    "object\0objID\0KDEAnalyze\0bandWidth\0"
    "float**\0loc\0maxLoc\0minLoc\0updateMyGLSlot\0"
    "mode\0const char*\0filename\0layerID\0"
    "updateMyGLPostgresqlSlot\0port\0dbname\0"
    "host\0user\0password\0table\0updateData\0"
    "CGeoMap*\0map\0size\0updateLayerID\0LayerID\0"
    "getColorAndWidthData2\0fillColor\0"
    "strokeColor\0width\0getColorAndWidthOneObj\0"
    "getColorAndWidthObjs\0vector<QString>\0"
    "names\0restore\0KDEAnaly\0setLayerClours\0"
    "attribute"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MyGLWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   74,    2, 0x06 /* Public */,
       6,    4,   79,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    3,   88,    2, 0x0a /* Public */,
      17,    8,   95,    2, 0x0a /* Public */,
      24,    4,  112,    2, 0x0a /* Public */,
      28,    2,  121,    2, 0x0a /* Public */,
      30,    4,  126,    2, 0x0a /* Public */,
      34,    4,  135,    2, 0x0a /* Public */,
      35,    4,  144,    2, 0x0a /* Public */,
      38,    1,  153,    2, 0x0a /* Public */,
      39,    1,  156,    2, 0x0a /* Public */,
      40,    2,  159,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int,    4,    5,
    QMetaType::Void, QMetaType::Float, 0x80000000 | 8, QMetaType::Float, QMetaType::Float,    7,    9,   10,   11,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, 0x80000000 | 14, QMetaType::Int,   13,   15,   16,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   13,   16,   18,   19,   20,   21,   22,   23,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 25, QMetaType::Int, QMetaType::Int,   13,   26,   16,   27,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   13,   29,
    QMetaType::Void, QMetaType::Int, QMetaType::QColor, QMetaType::QColor, QMetaType::Float,   16,   31,   32,   33,
    QMetaType::Void, QMetaType::Int, QMetaType::QColor, QMetaType::QColor, QMetaType::Float,    5,   31,   32,   33,
    QMetaType::Void, 0x80000000 | 36, QMetaType::QColor, QMetaType::QColor, QMetaType::Float,   37,   31,   32,   33,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   16,   41,

       0        // eod
};

void MyGLWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MyGLWidget *_t = static_cast<MyGLWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->showAttriTable((*reinterpret_cast< CGeoObject*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: _t->KDEAnalyze((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float**(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 2: _t->updateMyGLSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const char*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 3: _t->updateMyGLPostgresqlSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8]))); break;
        case 4: _t->updateData((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< CGeoMap*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 5: _t->updateLayerID((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 6: _t->getColorAndWidthData2((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2])),(*reinterpret_cast< QColor(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 7: _t->getColorAndWidthOneObj((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2])),(*reinterpret_cast< QColor(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 8: _t->getColorAndWidthObjs((*reinterpret_cast< vector<QString>(*)>(_a[1])),(*reinterpret_cast< QColor(*)>(_a[2])),(*reinterpret_cast< QColor(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4]))); break;
        case 9: _t->restore((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->KDEAnaly((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->setLayerClours((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MyGLWidget::*_t)(CGeoObject * , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyGLWidget::showAttriTable)) {
                *result = 0;
            }
        }
        {
            typedef void (MyGLWidget::*_t)(float , float * * , float , float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MyGLWidget::KDEAnalyze)) {
                *result = 1;
            }
        }
    }
}

const QMetaObject MyGLWidget::staticMetaObject = {
    { &QOpenGLWidget::staticMetaObject, qt_meta_stringdata_MyGLWidget.data,
      qt_meta_data_MyGLWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MyGLWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MyGLWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MyGLWidget.stringdata0))
        return static_cast<void*>(const_cast< MyGLWidget*>(this));
    if (!strcmp(_clname, "QOpenGLFunctions_4_5_Core"))
        return static_cast< QOpenGLFunctions_4_5_Core*>(const_cast< MyGLWidget*>(this));
    return QOpenGLWidget::qt_metacast(_clname);
}

int MyGLWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QOpenGLWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void MyGLWidget::showAttriTable(CGeoObject * _t1, int _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MyGLWidget::KDEAnalyze(float _t1, float * * _t2, float _t3, float _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
