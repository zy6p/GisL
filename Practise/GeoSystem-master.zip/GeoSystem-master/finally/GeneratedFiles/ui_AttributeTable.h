/********************************************************************************
** Form generated from reading UI file 'AttributeTable.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ATTRIBUTETABLE_H
#define UI_ATTRIBUTETABLE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form8
{
public:

    void setupUi(QWidget *Form8)
    {
        if (Form8->objectName().isEmpty())
            Form8->setObjectName(QStringLiteral("Form8"));
        Form8->resize(400, 300);

        retranslateUi(Form8);

        QMetaObject::connectSlotsByName(Form8);
    } // setupUi

    void retranslateUi(QWidget *Form8)
    {
        Form8->setWindowTitle(QApplication::translate("Form8", "Form", 0));
    } // retranslateUi

};

namespace Ui {
    class Form8: public Ui_Form8 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ATTRIBUTETABLE_H
