/********************************************************************************
** Form generated from reading UI file 'KernelWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KERNELWIDGET_H
#define UI_KERNELWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form10
{
public:

    void setupUi(QWidget *Form10)
    {
        if (Form10->objectName().isEmpty())
            Form10->setObjectName(QStringLiteral("Form10"));
        Form10->resize(737, 588);

        retranslateUi(Form10);

        QMetaObject::connectSlotsByName(Form10);
    } // setupUi

    void retranslateUi(QWidget *Form10)
    {
        Form10->setWindowTitle(QApplication::translate("Form10", "Form", 0));
    } // retranslateUi

};

namespace Ui {
    class Form10: public Ui_Form10 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KERNELWIDGET_H
